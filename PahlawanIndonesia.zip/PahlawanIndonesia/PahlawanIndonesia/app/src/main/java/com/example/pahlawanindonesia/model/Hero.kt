package com.example.pahlawanindonesia.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize


@Parcelize
data class Hero(
    var nama: String,
    var deskripsi: String,
    var foto: Int
) : Parcelable



/*
nim : 10122066
nama: Nurul Fithriani Zahra
kelas: IF-2
*/